#!/usr/bin/env python
def normal(seq):
 print("Hello World")
