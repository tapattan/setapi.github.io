from setuptools import setup

setup(
     name='tapattan',    # This is the name of your PyPI-package.
     version='0.14',    # Update the version number for new releases
     author='nattapat attiratanasunthron',
     author_email='tapattan@gmail.com',
     url='https://github.com/tapattan/setapi.github.io',
     download_url='https://github.com/tapattan/setapi.github.io/raw/master/tapattan-0.1.tar.gz',
     packages=['normal']
     )
