from setuptools import setup

setup(
     name='tapattan',    # This is the name of your PyPI-package.
     version='0.1',    # Update the version number for new releases
     author='nattapat attiratanasunthron',
     author_email='tapattan@gmail.net',
     url='http://www.python.org/sigs/distutils-sig/',
     packages=['normal']
     )
