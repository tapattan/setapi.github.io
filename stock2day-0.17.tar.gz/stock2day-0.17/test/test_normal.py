# -*- coding: utf-8 -*-
# nattapat attiratanasunthron
# email :  tapattan@gmail.com, 04/2017.
import numpy as py
from stock2day import normal,denormal

data = np.asarray([10,20,30,40,50,60,70,80,90]);
print(data)

data_tmp = normal(data)

print(data_tmp)

data_tmp2 = denormal(data_tmp)

print(data_tmp)
