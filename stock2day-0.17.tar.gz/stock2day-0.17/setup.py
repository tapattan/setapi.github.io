from setuptools import setup

setup(
     name='stock2day',    # This is the name of your PyPI-package.
     version='0.17',    # Update the version number for new releases
     author='nattapat attiratanasunthron',
     author_email='tapattan@gmail.com',
     url='https://github.com/tapattan/setapi.github.io',
     download_url='https://github.com/tapattan/setapi.github.io/raw/master/tapattan-0.16.tar.gz',
     packages=['stock2day']
     )
