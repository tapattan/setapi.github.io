#!/usr/bin/env python
import requests

def normal(data):
 return (data - data.mean())/data.std()


def denormal(data,dataO):
    return (data * dataO.std()) + dataO.mean()


def getstock(symbol):
  url = "http://52.187.183.101:7777/getstock/"+symbol
  r = requests.get(url)
  #print(r.url)
  return r.text
 
