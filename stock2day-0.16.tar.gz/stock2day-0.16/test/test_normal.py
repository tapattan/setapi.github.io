# -*- coding: utf-8 -*-
# nattapat attiratanasunthron
# email :  tapattan@gmail.com, 04/2017.

from stock2day import normal

normal(5)
